# Automatizado Tech

Site institucional da **Automatizado Tech**, empresa focada em **automações web e educação tecnológica**.

## 🚀 Slogan
> Faça MAIS com Menos

## 🧩 Estrutura
- `index.html`: Página principal
- `assets/css/style.css`: Estilos globais
- `assets/img/`: Logos e banners
- `cursos.html`, `servicos.html`, `contato.html`: Páginas futuras

## 🌐 Deploy
Recomendado: [Cloudflare Pages](https://pages.cloudflare.com)
